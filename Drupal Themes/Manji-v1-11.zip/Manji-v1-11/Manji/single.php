<?php include "header.php"; ?>
 <div id="container">
  <div id="topcontent"></div>
  <div id="content">
   <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
   
    <div class="postnavigation">
     <div class="right">
      <?php next_post(' % &raquo;','','yes') ?>
     </div>
     <div class="left">
      <?php previous_post('&laquo; %','','yes') ?>
     </div>
    </div>
  
    <div class="post">
     <div class="title" id="post-<?php the_ID(); ?>">
      <a href="<?php the_permalink() ?>" rel="bookmark">
       <?php the_title(); ?>
      </a>
     </div>
     <h3><span class="posted"><?php _e("Posted on "); ?></span>
      <?php the_time('l j F Y',display); ?>  
     </h3>

     <div class="storycontent">
      <?php the_content(__('(more...)')); ?>
     

</div>  <?php wp_link_pages(); ?> 
    </div>

    <?php comments_template(); ?>
    <?php endwhile; else: ?>
    <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
   <?php endif; ?>
   <div id="bottomcontent"></div>
  </div>
 </div>

<?php include('searchform.php'); ?>

<?php include('footer.php'); ?>