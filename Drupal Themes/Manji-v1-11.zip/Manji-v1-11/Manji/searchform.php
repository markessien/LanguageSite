<div id="menu">
 <form id="searchform" method="get" action="<?php echo $PHP_SELF; ?>">
  <input id="searchbutton" type="submit" name="submit" value="<?php _e('Search'); ?>" />
  <input type="text" name="s" id="search" size="15" />
 </form> 
 <div id="topimage"> 
  <a href="#"></a>  
 </div>
</div>