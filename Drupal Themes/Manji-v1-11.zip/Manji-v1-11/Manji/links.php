<?php /*
Template Name: Links
*/ ?>

<?php include "header.php"; ?>
 <div id="container">
  <div id="topcontent"></div>
  <div id="content">
   <div class="clearer">&nbsp;</div>
    <div class="post">
     <h2>Links:</h2>
     <ul>
      <?php get_links_list(); ?>
     </ul>
    </div>	
   <div id="bottomcontent">&nbsp;</div>
  </div>
 </div>

<?php include('searchform.php'); ?>

<?php include('footer.php'); ?>