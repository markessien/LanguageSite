<a name = "bottom"></a>
<div id="footer">
 <p class="credits"><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> is &copy; 2004 <?php the_author() ?>. 
  <a href="http://www.brokenkode.com/manji">Manji</a> by Khaled Abou Alfa and <a href="http://www.atthe404.com">Root</a>.  
    You can syndicate <br /> both the entries using <a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>">
    <?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?></a> and the <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)
  </a>. 

  <a href="http://validator.w3.org/check/referer">xhtml 1.0 trans </a>/ 

  <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS </a>. 

  <?php echo sprintf(__("Proudly powered by <a href='http://wordpress.org' title='%s'><strong>WordPress</strong></a>"), __("Powered by WordPress, state-of-the-art semantic personal publishing platform")); ?>.
 </p>
 <p class="wordpress"></p>
</div>



<?php do_action('wp_footer', ''); ?>

</body>
</html>