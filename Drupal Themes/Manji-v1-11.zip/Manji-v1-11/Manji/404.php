<?php include "header.php"; ?>
 <div id="container">
  <div id="topcontent"></div>
  <div id="content">
   <div class="clearer">&nbsp;</div>
    <div class="title">
 Error 404 - Page Not Found.
     </div>   
   <div id="bottomcontent">&nbsp;</div>
  </div>
 </div>

<?php include('searchform.php'); ?>

<?php include('footer.php'); ?>