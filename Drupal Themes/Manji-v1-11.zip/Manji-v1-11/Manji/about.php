<?php /*
    Template Name: About
   */
?>

<?php include "header.php"; ?>
 <div id="container">
  <div id="topcontent"></div>
  <div id="content">
   <div class="clearer">&nbsp;</div>
    <div class="post">
   <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <?php the_content(); ?>
   <?php endwhile; endif; ?>
    </div>   
   <div id="bottomcontent">&nbsp;</div>
  </div>
 </div>

<?php include('searchform.php'); ?>

<?php include('footer.php'); ?>
