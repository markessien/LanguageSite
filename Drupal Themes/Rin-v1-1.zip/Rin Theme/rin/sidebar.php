<div id="sidebar">
 <ul>
 
<?php wp_list_pages('title_li=<h2>' . __('Pages') . '</h2>' ); ?>




  <li><h2><?php _e('Categories'); ?></h2>
   <ul>
    <?php list_cats() ?>
   </ul>
  </li>

  <li><h2><?php _e('Links'); ?></h2>
   <ul>
    <?php get_links('-1', '<li>', '</li>', '<br />'); ?>
   </ul>
  </li>
  

 </ul>
</div>

